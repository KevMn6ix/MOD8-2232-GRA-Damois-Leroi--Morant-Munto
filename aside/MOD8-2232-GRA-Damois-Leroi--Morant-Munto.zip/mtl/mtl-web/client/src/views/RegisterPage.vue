<script setup>
import Register from '../components/Register.vue'
</script>

<template>
    <Register />
</template>

<style>
</style> 