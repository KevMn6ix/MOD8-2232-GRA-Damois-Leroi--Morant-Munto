<script setup>
import Login from '../components/Login.vue'
import BarOutsideHome from '../components/BarOutsideHome.vue';
</script>

<template>
<header>
    <BarOutsideHome/>
</header>
    <Login />
</template>

<style>

</style> 