<script setup>
import PlaceFormRating from '../components/PlaceFormRating.vue';
import BarOutsideHome from '../components/BarOutsideHome.vue';
</script>

<template>
    <header>
        <BarOutsideHome/>
    </header>
    <div>
        <PlaceFormRating />
    </div>
</template>
